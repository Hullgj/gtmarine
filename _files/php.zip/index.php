<?php
require_once('php/router.php');
include('home.php');
print_r($requestURI);
print_r($scriptName);

?>
	  